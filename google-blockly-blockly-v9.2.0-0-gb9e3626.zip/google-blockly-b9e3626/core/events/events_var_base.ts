/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Abstract class for a variable event.
 *
 * @class
 */
import * as goog from '../../closure/goog/goog.js';
goog.declareModuleId('Blockly.Events.VarBase');

import * as deprecation from '../utils/deprecation.js';
import type {VariableModel} from '../variable_model.js';

import {Abstract as AbstractEvent, AbstractEventJson} from './events_abstract.js';
import type {Workspace} from '../workspace.js';


/**
 * Abstract class for a variable event.
 *
 * @alias Blockly.Events.VarBase
 */
export class VarBase extends AbstractEvent {
  override isBlank = true;
  varId?: string;

  /**
   * @param opt_variable The variable this event corresponds to.  Undefined for
   *     a blank event.
   */
  constructor(opt_variable?: VariableModel) {
    super();
    this.isBlank = typeof opt_variable === 'undefined';
    if (!opt_variable) return;

    /** The variable id for the variable this event pertains to. */
    this.varId = opt_variable.getId();

    /** The workspace identifier for this event. */
    this.workspaceId = opt_variable.workspace.id;
  }

  /**
   * Encode the event as JSON.
   *
   * @returns JSON representation.
   */
  override toJson(): VarBaseJson {
    const json = super.toJson() as VarBaseJson;
    if (!this.varId) {
      throw new Error(
          'The var ID is undefined. Either pass a variable to ' +
          'the constructor, or call fromJson');
    }
    json['varId'] = this.varId;
    return json;
  }

  /**
   * Decode the JSON event.
   *
   * @param json JSON representation.
   */
  override fromJson(json: VarBaseJson) {
    deprecation.warn(
        'Blockly.Events.VarBase.prototype.fromJson', 'version 9', 'version 10',
        'Blockly.Events.fromJson');
    super.fromJson(json);
    this.varId = json['varId'];
  }

  /**
   * Deserializes the JSON event.
   *
   * @param event The event to append new properties to. Should be a subclass
   *     of VarBase, but we can't specify that due to the fact that parameters
   *     to static methods in subclasses must be supertypes of parameters to
   *     static methods in superclasses.
   * @internal
   */
  static fromJson(json: VarBaseJson, workspace: Workspace, event?: any):
      VarBase {
    const newEvent =
        super.fromJson(json, workspace, event ?? new VarBase()) as VarBase;
    newEvent.varId = json['varId'];
    return newEvent;
  }
}

export interface VarBaseJson extends AbstractEventJson {
  varId: string;
}
