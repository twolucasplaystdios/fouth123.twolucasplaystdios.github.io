/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Events fired as a result of bubble open.
 *
 * @class
 */
import * as goog from '../../closure/goog/goog.js';
goog.declareModuleId('Blockly.Events.BubbleOpen');

import type {AbstractEventJson} from './events_abstract.js';
import type {BlockSvg} from '../block_svg.js';
import * as deprecation from '../utils/deprecation.js';
import * as registry from '../registry.js';
import {UiBase} from './events_ui_base.js';
import * as eventUtils from './utils.js';
import type {Workspace} from '../workspace.js';


/**
 * Class for a bubble open event.
 *
 * @alias Blockly.Events.BubbleOpen
 */
export class BubbleOpen extends UiBase {
  blockId?: string;
  isOpen?: boolean;
  bubbleType?: BubbleType;
  override type = eventUtils.BUBBLE_OPEN;

  /**
   * @param opt_block The associated block. Undefined for a blank event.
   * @param opt_isOpen Whether the bubble is opening (false if closing).
   *     Undefined for a blank event.
   * @param opt_bubbleType The type of bubble. One of 'mutator', 'comment' or
   *     'warning'. Undefined for a blank event.
   */
  constructor(
      opt_block?: BlockSvg, opt_isOpen?: boolean, opt_bubbleType?: BubbleType) {
    const workspaceId = opt_block ? opt_block.workspace.id : undefined;
    super(workspaceId);
    if (!opt_block) return;

    this.blockId = opt_block.id;

    /** Whether the bubble is opening (false if closing). */
    this.isOpen = opt_isOpen;

    /** The type of bubble. One of 'mutator', 'comment', or 'warning'. */
    this.bubbleType = opt_bubbleType;
  }

  /**
   * Encode the event as JSON.
   *
   * @returns JSON representation.
   */
  override toJson(): BubbleOpenJson {
    const json = super.toJson() as BubbleOpenJson;
    if (this.isOpen === undefined) {
      throw new Error(
          'Whether this event is for opening the bubble is undefined. ' +
          'Either pass the value to the constructor, or call fromJson');
    }
    if (!this.bubbleType) {
      throw new Error(
          'The type of bubble is undefined. Either pass the ' +
          'value to the constructor, or call fromJson');
    }
    json['isOpen'] = this.isOpen;
    json['bubbleType'] = this.bubbleType;
    json['blockId'] = this.blockId || '';
    return json;
  }

  /**
   * Decode the JSON event.
   *
   * @param json JSON representation.
   */
  override fromJson(json: BubbleOpenJson) {
    deprecation.warn(
        'Blockly.Events.BubbleOpen.prototype.fromJson', 'version 9',
        'version 10', 'Blockly.Events.fromJson');
    super.fromJson(json);
    this.isOpen = json['isOpen'];
    this.bubbleType = json['bubbleType'];
    this.blockId = json['blockId'];
  }

  /**
   * Deserializes the JSON event.
   *
   * @param event The event to append new properties to. Should be a subclass
   *     of BubbleOpen, but we can't specify that due to the fact that
   *     parameters to static methods in subclasses must be supertypes of
   *     parameters to static methods in superclasses.
   * @internal
   */
  static fromJson(json: BubbleOpenJson, workspace: Workspace, event?: any):
      BubbleOpen {
    const newEvent =
        super.fromJson(json, workspace, event ?? new BubbleOpen()) as
        BubbleOpen;
    newEvent.isOpen = json['isOpen'];
    newEvent.bubbleType = json['bubbleType'];
    newEvent.blockId = json['blockId'];
    return newEvent;
  }
}

export enum BubbleType {
  MUTATOR = 'mutator',
  COMMENT = 'comment',
  WARNING = 'warning',
}

export interface BubbleOpenJson extends AbstractEventJson {
  isOpen: boolean;
  bubbleType: BubbleType;
  blockId: string;
}

registry.register(registry.Type.EVENT, eventUtils.BUBBLE_OPEN, BubbleOpen);
